pub mod device_inventory;
pub mod memory_device_inventory;
